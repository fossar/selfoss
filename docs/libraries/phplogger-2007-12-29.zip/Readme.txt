README

I am having more than 6 years of experience in coding. I started my career with PHP and presently I am in Java, J2EE. I have a good proficiency in Web-Services, Struts, Database, PHP, Linux. You can contact me on singhgurdeep@gmail.com for any type of help.

I am contributing PHP classes to this site. PHPClasses.org class helped me a lot when I was fresher, so I thanks to PHPClasses and I am contributing to this site.

PHPLogger

This class is used to log the information in the file. You just need to make the instance of the class and call the write method to log the required information. This class can be helpful to debug the application. This class can also be used with database queries to log the information on queries and log the time taken by the query to execute. You can find this example in my database related class. I provided the wrapper to the database class. This means that you need not have to open the connection, select the datrabase, and call other mysql function everytime.

You can also define the severity of message as DEBUG, INFO, NOTICE, WARNING, ERROR. These severity will added to Log file. This makes easy to read logs. The logs are created with date and time with message.

Usage example can also be seen in testLogger.php file.

Feel free to make any changes to the class and use it in the way you like.

Though I do not commit anything but please suggest any improvements on singhgurdeep@gmail.com