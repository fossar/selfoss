<?php

	class TestLogger {
		public static function testDebug() {
			require_once('PHPLogger.php');
			$logger = PHPLogger::getInstance();
			$logger->write("This is the test message to write to log file ", DEBUG, "test Log");
			
			print "Debugging... <br /><br />";
		}

		public static function testWarning() {
			require_once('PHPLogger.php');
			$logger = PHPLogger::getInstance();
			$logger->write("This is the test message to write to log file ", WARNING, "test Log");
			
			print "Warning... <br /><br />";
		}
		
		public static function testError() {
			require_once('PHPLogger.php');
			$logger = PHPLogger::getInstance();
			$logger->write("This is the test message to write to log file ", ERROR, "test Log");
			
			print "Error... <br /><br />";
		}
		
		public static function testInfo() {
			require_once('PHPLogger.php');
			$logger = PHPLogger::getInstance();
			$logger->write("This is the test message to write to log file ", INFO, "test Log");
			
			print "Info... <br /><br />";
		}
	
		public static function testNotice() {
			require_once('PHPLogger.php');
			$logger = PHPLogger::getInstance();
			$logger->write("This is the test message to write to log file ", NOTICE, "test Log");
			
			print "Notice... <br /><br />";
		}
	}
?>


<html>
	<head>
		<title>
			Logger test script
		</title>
	</head>
<?php
	TestLogger::testDebug();
	TestLogger::testWarning();
	TestLogger::testError();
	TestLogger::testInfo();
	TestLogger::testNotice();
?>
	<body>
		<table cellspacing="0" cellpadding="0" width="100%" align="center">
			<tr>
				<td>
					Logging successfull..
				</td>
			</tr>
		</table>
	</body>
</html>
