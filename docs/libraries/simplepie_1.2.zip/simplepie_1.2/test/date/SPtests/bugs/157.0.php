<?php

class SimplePie_Date_Test_Bug_157_Test_0 extends SimplePie_Date_Test
{
	function data()
	{
		$this->data = 'meep';
	}
	
	function expected()
	{
		$this->expected = false;
	}
}

?>